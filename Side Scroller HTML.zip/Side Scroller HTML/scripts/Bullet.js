/* name- Bullet.js
author- Slater de Mont
last modified- 10/20/2018
description-a constructor that creates a Bullet
dependencies- requires global variables: CANVAS_WIDTH,CANVAS_HEIGHT
*/
"use strick";
window.Bullet =(function(){

	function Bullet(x,y,speed){
		//ivars - unique for every instance
		this.x=x;
		this.y=y;
		this.active=true;
		//make the bullet come from the gun and head in the right direction
		if(playerFacingRight){
			this.xVelocity = +speed;
			this.x= x + 20;
		}
		//make the bullet head in the opposite direction
		else{
			this.xVelocity = -speed;
			this.x= x - 25;
		}
		this.yVelocity = 0;
		this.width=8;
		this.height=3;
		this.color="#FFF";
	}//end bullet Constructor
	
	//Bullet methods - all instances share on copy of each function through .prototype
	
	Bullet.prototype.inBounds = function(){
				return this.x >=0 && this.x <=CANVAS_WIDTH && this.y >=0 && this.y<= CANVAS_HEIGHT;
	};
	
	Bullet.prototype.update = function(dt){
		this.x += this.xVelocity * dt;
		this.y += this.yVelocity * dt;
		this.active = this.active && this.inBounds();
	};
	
	Bullet.prototype.draw = function(ctx){
		ctx.fillStyle = this.color;
		ctx.fillRect(this.x, this.y, this.width, this.height);
	};
	
	return Bullet;//return the Buller constructor
})();//self-executing anonymous function