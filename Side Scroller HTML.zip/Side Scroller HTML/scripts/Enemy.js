/* name- Enemy.js
author- Slater de Mont
last modified- 10/2/2013
description-a constructor that creates a Enemy
dependencies- 
*/
"use strict";
window.Enemy =(function(){

	function Enemy(cW, cH) {
		
		//ivars
		this.active = true;
		this.age = Math.floor(Math.random() * 128);
		this.canvasWidth = cW;
		this.canvasHeight = cH;
		this.color = "#A2B";
		
		this.x = CANVAS_WIDTH/4 +Math.random() * CANVAS_WIDTH/2;
		this.y=0;
		this.xVelocity = 0;
		this.yVelocity = 200;
		this.amplitude = getRandom(1,5,7,0);
		
		this.width = 34;
		this.height = 40;
		
	};
	
	//Enemy methods
	Enemy.prototype.inBounds=function(){
		return this.x >= 0 && this.x <= this.canvasWidth &&
			this.y >= 0 && this.y <= this.canvasHeight;
	};
	
	Enemy.prototype.draw = function(ctx){
	
		var halfW = this.width/2;
		var halfH = this.height/2;
		//use this if your image file has just 1 sprite
		//ctx.drawImage(images["enemyImage"],this.x - halfW, this.y-halfH, this.width, this.height);
		
		//draw from sprite sheet
		
		ctx.drawImage(images["enemyImage"], //source image 
			206, 415, 193, 169,
			this.x-halfW, this.y-halfH, this.width, this.height
		);
	};
	
	Enemy.prototype.update = function(dt){
		this.xVelocity = this.amplitude * Math.sin(this.age * Math.PI * dt);
		this.x += this.xVelocity;
		this.y += this.yVelocity * dt;
		this.age++;
		this.active = this.active && this.inBounds();
	};
	
	Enemy.prototype.explode = function(){
		this.active = false;
	};
	
	return Enemy;
	
})();