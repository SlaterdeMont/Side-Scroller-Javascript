/* name- playerControl.js
author- Slater de Mont
last modified- 10/26/2018
description-singleton object representing player
dependencies- uses global variables: images,keydown,KEYBOARD
*/
"use strict";
window.background = (function(){
	var tickCount = 0;
	var isFacingRight = true;
	
	var background = {
		draw: function(ctx){
			ctx.drawImage(images["backgroundImage"], tickCount, 0, 5000,480, 0, 0, 13000,1560);

			
			//if D is pressed, animate right
			if(keydown[68]){
				tickCount+= .25;
				if(isFacingRight == false){
				 	isFacingRight = true;
				}

        		if(tickCount >= images["backgroundImage"].width){
        			tickCount = 0;
        	    }
			}
			
			if(keydown[65]){
				if(playerX >= 0){
					tickCount-= .25;
					if(isFacingRight == true){
					 	isFacingRight = false;
					}
				
        			if(tickCount >= images["backgroundImage"].width){
        				tickCount = 0;
        			}
        		}
			}
		}
	};
	
	return background;
})();//self executing anonymous function