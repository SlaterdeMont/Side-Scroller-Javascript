/* name- playerControl.js
author- Slater de Mont
last modified- 10/26/2018
description-singleton object representing player
dependencies- uses global variables: images,keydown,KEYBOARD
*/

"use strict";
window.backgroundObject =(function(){

	var isFacingRight = true;

	function backgroundObject(imgSrc, speed, ypos, width, height) {
		this.tickCount = 0;
		this.backgroundImage = imgSrc;
		this.imgHeight = height;
		this.yPos = ypos;
		this.imgWidth = width;
		this.imgSpeed = speed;
		this.backgroundObjectImage = new Image();
		this.backgroundObjectImage.src = this.backgroundImage;
	};
	
	backgroundObject.prototype.draw = function(ctx){

		//console.log(imgSpeed + " speed " + backgroundImage);
		ctx.drawImage(this.backgroundObjectImage, this.tickCount, this.yPos, 6000,480, 0, 0, this.imgWidth, this.imgHeight);

		
		//if D is pressed, animate right
		if(keydown[68]){
			this.tickCount+= this.imgSpeed;
			if(isFacingRight == false){
			 	isFacingRight = true;
			}

        	if(this.tickCount >= this.backgroundObjectImage.width){
        		this.tickCount = 0;
            }
		}
		
		if(keydown[65]){
			if(playerX >= 0){
				this.tickCount-= this.imgSpeed;
				if(isFacingRight == true){
				 	isFacingRight = false;
				}
			
        		if(this.tickCount >= this.backgroundObjectImage.width){
        			this.tickCount = 0;
        		}
        	}
		}
	};
	
	return backgroundObject;
})();