/* name- playerControl.js
author- Slater de Mont
last modified- 10/26/2018
description-singleton object representing player
dependencies- uses global variables: images,keydown,KEYBOARD
*/

"use strict";
window.groundObject =(function(){

	var isFacingRight = true;

	function groundObject(imgSrc, xSpripos, ySpripos, wPos, hPos, xpos, ypos, width, height) {
		this.tickCount = 0;
		this.groundImage = imgSrc;
		this.imgHeight = height;
		this.yPos = ypos;
		this.xPos = xpos;
		this.ySpriPos = ySpripos;
		this.xSpriPos = xSpripos;
		this.wPos = wPos;
		this.hPos = hPos;
		this.imgWidth = width;
		this.imgSpeed = .7;
		this.xPosForPosition = xpos;
		this.groundObjectImage = new Image();
		this.groundObjectImage.src = this.groundImage;
	};
	
	groundObject.prototype.draw = function(ctx){

		//console.log(imgSpeed + " speed " + backgroundImage);
		ctx.drawImage(this.groundObjectImage, this.xSpriPos, this.ySpriPos, this.wPos, this.hPos, (this.tickCount + this.xPos), this.yPos, this.imgWidth, this.imgHeight);
		
		//if D is pressed, animate right
		if(keydown[68]){
			this.tickCount-= this.imgSpeed;

        	//if(this.tickCount >= this.groundObjectImage.width){
        	//	this.tickCount = 0;
           // }
		}
		
		if(keydown[65]){
			if(playerX >= 0){
				this.tickCount+= this.imgSpeed;
			
        		if(this.tickCount >= this.groundObjectImage.width){
        			this.tickCount = 0;
        		}
        	}
		}
	};
	
	return groundObject;
})();