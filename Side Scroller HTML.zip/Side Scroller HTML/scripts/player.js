/* name- playerControl.js
author- Slater de Mont
last modified- 10/26/2018
description-singleton object representing player
dependencies- uses global variables: images,keydown,KEYBOARD
*/
"use strict";
window.player = (function(){
	var tickCount = 0;
	var ticksPerFrame = 8;
	var spritePos = 67;
	var imgWidth = 67;
	var rightMove = "images/marIMG/rightSprite.png";
	var leftMove = "images/marIMG/leftSprite.png";
	var isFacingRight = true;
	var isJumping = false;
	var jumpCount = 0;
	var isOnPlatform = true;
	var y;
	var x;
	
	var player = {
		color:"yellow",
		x:100,
		y:400,
		width:imgWidth,
		height:72,
		speed:200,
		draw: function(ctx){
			var halfW=this.width/2;
			var halfH = this.height/2;
			ctx.drawImage(images["playerImage"],//source image
				spritePos,0,67,72, //source coords and width, height
				this.x - halfW, this.y-halfH, this.width, this.height
			);
			var numPlats = 0;
			groundPieces.forEach(function(groundPiece){
				if(groundPiece != null){

					if(groundPiece.xPosForPosition < playerX + player.width && groundPiece.xPosForPosition + groundPiece.imgWidth > playerX && groundPiece.yPos < (player.y + player.height - 50) && (groundPiece.yPos + player.height) > player.y){
						//console.log("player touched platform");
						isOnPlatform = true;
					}
					else{
						numPlats++;
					}
					if(numPlats >= groundPieces.length){
						isOnPlatform = false;
					}
				}
			});
			
			//if D is pressed, animate right
			if(keydown[68]){
				if(isFacingRight == false){
					playerFacingRight = true;
				 	images["playerImage"].src = rightMove;
				 	tickCount = 0;
				 	spritePos = 0;
				 	isFacingRight = true;
				}
				
				playerX+= 1;
				tickCount += 1;
        		if (tickCount > ticksPerFrame) {
        			
        			tickCount = 0; 
					
					spritePos += imgWidth;
        			if(spritePos >= images["playerImage"].width){
        				spritePos = 0;
        			}
        	    }
			}
			
			//if key pressed is A, animate left
			if(keydown[65]){
				if(isFacingRight == true){
					playerFacingRight = false;
				 	images["playerImage"].src = leftMove;
				 	tickCount = 0;
				 	spritePos = 0;
				 	isFacingRight = false;
				}
				
				if(playerX >= 0){
					playerX--;
					tickCount += 1;
        			if (tickCount > ticksPerFrame) {
        			
        				tickCount = 0; 
					
						spritePos += imgWidth;
        				if(spritePos >= images["playerImage"].width){
        					spritePos = 0;
        				}
        	   		}
        	    }
        	}
        	    
        	//if keydown is W, jump
        	if(keydown[87]){
        	    if(isJumping == false){
        	    	isJumping = true;
        	    	player.y -= 10;
        	    	jumpCount = 0;
        	    }
			}
			
			if(isJumping == true && jumpCount < 20){
				jumpCount++;
				player.y -= 5;
			}else{
				if(isOnPlatform == true){
					isJumping = false;
					jumpCount = 0;
				}else{
					player.y += 5;
				}
			}
						
		},//end draw() method
		
		initParticle: function(p){
			var halfW = this.width/2;
			
			//getRadom(min,max) from utils.js
			p.x=getRandom(-halfW, halfW);
			p.y=getRandom(0,this.height);
			p.r=getRandom(2,4);//radius
			p.xSpeed=getRandom(-0.5,0.5);
			p.ySpeed = getRandom(2,4);
			return p;
		},//end initPraticle
		
		createParticles:function(){
			//initialize particles array
			this.particles = [];
			
			//create 20 exhaust particles
			for(var i=0;i<20;i++){
			
				//create an "empty" particle object
				var p={};
				
				//give it a random age when first created
				p.age = getRandomInt(0,99);
				
				//add to array
				this.particles.push(this.initParticle(p));
				
			}
		},
		
		explode:function(){
			this.active = false;
			console.log("Player was hit!");
		}

	};//end player
	
	return player;
})();//self executing anonymous function